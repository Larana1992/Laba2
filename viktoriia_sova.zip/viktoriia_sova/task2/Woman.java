package com.epam.at.viktoriia_sova.task2;

import java.util.Random;
import java.util.Scanner;

public class Woman extends Human {

	

	Woman(String firstName, String lastName, float growth,
			float weight) {
		super(true,firstName,lastName,growth,weight);
		
	}

	// ������
	Human birth(Man man) {
		Random random = new Random();
		boolean sex1 = (random.nextDouble() <= 0.5) ? true : false;
		float growth1 = 0, weight1 = 0;
		String fl = (sex1 == false) ? "�������� :" : "������� :";
		Scanner Numbers = new Scanner(System.in);
		System.out.print("������� ��� ��� " + fl);
		String firstName1 = Numbers.nextLine();
		String lastName1 = man.lastName;
		if (this.sex == sex1) {
			growth1 = (float) (this.growth + 0.1 * (man.growth - this.growth));
		} else {
			growth1 = (float) (man.growth + 0.1 * (this.growth - man.growth));
		}
		if (this.sex == sex1) {
			weight1 = (float) (this.weight + 0.1 * (man.weight - this.weight));
		} else {
			weight1 = (float) (man.weight + 0.1 * (this.weight - man.weight));
		}

		return (sex1 == true) ? new Woman(firstName1, lastName1,
				growth1, weight1) : new Man(firstName1, lastName1,
				growth1, weight1);
	}
	
}
