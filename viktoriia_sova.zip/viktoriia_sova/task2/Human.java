package com.epam.at.viktoriia_sova.task2;

import java.util.Random;

public abstract class Human {
	boolean sex = false;// ���
	String firstName = "���";// ���
	String lastName = "�������";// �������
	float growth = 1.7f;// ����
	float weight = 60f;// ���
	Human(boolean sex, String firstName, String lastName, float growth,
			float weight) {
		this.setSex(sex);
		this.setFirstName(firstName);
		this.setLastName(lastName);
		this.setGrowth(growth);
		this.setWeight(weight);
	}
	// ��������
	boolean speak(Human hum) {
		Random random = new Random();
		if (this.sex == false && this.sex == hum.sex) {
			if (random.nextDouble() > 0.5)
				return true;
			else
				return false;
		} else {
			return true;
		}
	}

	// �������, ��������� ��������
	boolean sustainSociety(Human hum) {
		Random random = new Random();
		if (this.sex != hum.sex) {
			if (random.nextDouble() <= 0.7)
				return true;
			else if (this.sex == true)
				if (random.nextDouble() <= 0.05)
					return true;
				else if (this.sex == true)
					if (random.nextDouble() <= 0.056)
						return true;
		}
		return false;
	}

	// ��������� ����� ������
	boolean spendTimeTogether(Human hum) {
		Random random = new Random();
		double percent = Math.abs(100 - (hum.growth * 100) / this.growth);
		if (percent > 10) {
			if (random.nextDouble() <= 0.85)
				return true;
		} else {
			if (random.nextDouble() <= 0.95)
				return true;
		}
		return false;
	}

	// ����� ���������
	Human haveRelationship(Human hum) {
		speak(hum);
		if (this.sex != hum.sex)
			if (spendTimeTogether(hum) == true && sustainSociety(hum) == true
					&& speak(hum) == true) {
				if (this.sex == true) {
					return ((Woman) this).birth((Man) hum);
				} else
					return ((Woman) hum).birth((Man) this);
			}
		return null;
	}

	public String toString() {
		String fl = (this.sex == false) ? "������� " : "������� ";
		return "� " + fl + "!!! \n" + "���: " + getFirstName() + "\n"
				+ "�������: " + getLastName() + "\n" + "����: " + getGrowth()
				+ "\n" + "���: " + getWeight() + "\n";
	}

	boolean getSex() {
		return sex;
	}

	void setSex(boolean sex) {
		this.sex = sex;
	}

	String getFirstName() {
		return firstName;
	}

	void setFirstName(String firstName) {
		if (firstName.equals("") == false)
			this.firstName = firstName;
	}

	String getLastName() {
		return lastName;
	}

	void setLastName(String lastName) {
		if (lastName.equals("") == false)
			this.lastName = lastName;
	}

	float getGrowth() {
		return growth;
	}

	void setGrowth(float growth) {
		if (growth > 0)
			this.growth = growth;
	}

	float getWeight() {
		return weight;
	}

	void setWeight(float weight) {
		if (weight > 0)
			this.weight = weight;
	}
}
