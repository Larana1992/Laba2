package com.epam.at.viktoriia_sova.task2;

public class Man extends Human {
	
	Man(String firstName, String lastName, float growth,
			float weight) {
		super(false,firstName,lastName,growth,weight);
	}
}
