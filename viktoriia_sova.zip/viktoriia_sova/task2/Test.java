package com.epam.at.viktoriia_sova.task2;

import java.util.ArrayList;

public class Test {
	static ArrayList<Human> two;

	static void add(String s) {
		String[] d = s.trim().split("\\s+");
		Human human;
		if (d[0].equals("0")) {
			human = new Man(d[1], d[2], Float.parseFloat(d[3]),
					Float.parseFloat(d[4]));
		} else {
			human = new Woman(d[1], d[2], Float.parseFloat(d[3]),
					Float.parseFloat(d[4]));
		}
		if (two == null) {
			two = new ArrayList<Human>();
		}
		two.add(human);
		if (two.size() == 2) {
			Human c = two.get(0).haveRelationship(two.get(1));
			if (c != null) {
				System.out.println(c);
				System.out.println("��� :" + c.getClass().getSimpleName());
			} else {
				System.out.println("����������� =(");

			}
			two.clear();
		}
	}
}
