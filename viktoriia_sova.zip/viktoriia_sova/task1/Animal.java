package com.epam.at.viktoriia_sova.task1;

public abstract class Animal {
	double cost;
	String name;
	String color;

	public void sleep() {
		System.out.println("� ���� =) ");
	}

	String getName() {
		return name;
	}

	void setName(String name) {
		if (name.equals("") == false)
			this.name = name;
	}

	String getColor() {
		return color;
	}

	void setColor(String color) {
		if (color.equals("") == false)
			this.color = color;
	}

	double getCost() {
		return cost;
	}

	void setCost(double cost) {
		if (cost > 0.0)
			this.cost = cost;
	}

	public String toString() {
		return "Hi";
	}
	
}
