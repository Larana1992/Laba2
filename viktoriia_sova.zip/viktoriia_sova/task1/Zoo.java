package com.epam.at.viktoriia_sova.task1;

public class Zoo {
	Animal[] anim;

	void add(Animal a) {
		if (anim == null) {
			anim = new Animal[0];
		}
		Animal[] s = new Animal[anim.length];
		for (int i = 0; i < s.length; i++) {
			s[i] = anim[i];
		}
		anim = new Animal[anim.length + 1];
		for (int i = 0; i < s.length; i++) {
			anim[i] = s[i];
		}
		anim[anim.length - 1] = a;
	}

	void print() {
		for (Animal a : anim) {
			System.out.println(a);
		}
		System.out.println("\n");
	}

	int count() {
		return anim.length;
	}

	Animal byIndex(int i) {
		if (i - 1 < anim.length && i - 1 > -1) {
			return anim[i-1];
		} else {
			return null;
		}
	}

	void sortByPrice() {
		int step = anim.length / 2;
		while (step > 0) {
			int i, j;
			for (i = step; i < anim.length; i++) {
				double value = anim[i].getCost();
				Animal an = anim[i];
				for (j = i - step; (j >= 0) && (anim[j].getCost() > value); j -= step) {
					anim[j + step] = anim[j];
				}
				anim[j + step] = an;
			}
			step /= 2;
		}
		// print();
	}

	void average() {
		double sumAll = 0, resultAll = 0;
		double sumCat = 0, resultCat = 0;
		int countCat = 0, countFish = 0;
		double sumFish = 0, resultFish = 0;

		for (int i = 0; i < anim.length; i++) {
			sumAll += anim[i].getCost();

			if (anim[i].getClass().getSimpleName().equals("Fish")) {
				sumFish += anim[i].getCost();
				countFish++;
			}
			if (anim[i].getClass().getSimpleName().equals("Cat")) {
				sumCat += anim[i].getCost();
				countCat++;
			}
		}
		resultAll = sumAll / anim.length;
		resultCat = sumCat / countCat;
		resultFish = sumFish / countFish;
		System.out.println("C������ ���� ��������: " + resultAll + " \n"
				+ "������� ���� ����: " + resultCat + " \n"
				+ "������� ���� ����: " + resultFish + " \n");

	}
}
