package com.epam.at.viktoriia_sova.task01;

import java.util.ArrayList;

public class Car {
	private ArrayList<Coffe> price;// �����
	private int id; // id
	private int volume;// �����
	private double cost;// ����� �����

	ArrayList<Coffe> getPrice() {
		return price;
	}

	private void setPrice(ArrayList<Coffe> price) {
		this.price = price;
	}

	double getCost() {
		return cost;
	}

	private void setCost(double cost) {
		if (cost > 0.0)
			this.cost = cost;
	}

	int getVolume() {
		return volume;
	}

	private void setVolume(int volume) {
		if (volume > 0)
			this.volume = volume;
	}

	int getId() {
		return id;
	}

	private void setId(int id) {
		if (id > 0)
			this.id = id;
	}

	Car(int id, int volume, double cost, ArrayList<Coffe> price) {
		super();
		this.setId(id);
		this.setCost(cost);
		this.setVolume(volume);
		this.setPrice(price);
	}
}
