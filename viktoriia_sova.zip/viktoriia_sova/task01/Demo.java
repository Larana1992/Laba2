package com.epam.at.viktoriia_sova.task01;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Functions func = new Functions();
		func.dialog1();
	}
}